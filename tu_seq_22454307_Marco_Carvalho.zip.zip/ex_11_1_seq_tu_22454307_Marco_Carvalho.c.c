#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void main(void)
{
	setlocale(LC_ALL, "Portuguese");
	int a,b,c;
	printf("\nDigite o valor de A:");
	scanf("%d",&a);
	printf("\nDigite o valor de B:");
	scanf("%d", &b);
	c=b;
	b=a;
	a=c;
	printf("Os valores invertidos sao\nA=%d\nB=%d",a,b);
}
