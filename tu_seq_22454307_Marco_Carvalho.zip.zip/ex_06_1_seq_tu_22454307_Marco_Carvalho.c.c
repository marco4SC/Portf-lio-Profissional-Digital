#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void main(void)
{
	setlocale(LC_ALL, "Portuguese");
	float R,pi,area;
	pi = 3.14;
	printf("\nDigite o valor do raio:");
	scanf("%f", &R);
	area = pi*R*R;
	printf("\nO valor da area da sua circunferencia e:%.2f",area);	
}

