#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void main(void)
{
	setlocale(LC_ALL, "Portuguese");
	float nt1,nt2,med;
	printf("\nDigite o valor da primeira nota:");
	scanf("%f", &nt1);
	printf("\nDigite o valor da segunda nota:");
	scanf("%f", &nt2);
	med = (nt1+nt2)/2;
	printf("\nO valor da media das notas e:%.2f",med);	
}

