#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void main(void)
{
	setlocale(LC_ALL, "Portuguese");
	float R,pi,comp;
	pi = 3.14;
	printf("\nDigite o valor do raio:");
	scanf("%f", &R);
	comp = pi*2*R;
	printf("\nO valor do comprimento da sua circunferencia e:%.2f",comp);	
}

