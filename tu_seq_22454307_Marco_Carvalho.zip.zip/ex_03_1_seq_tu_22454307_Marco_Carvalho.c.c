#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void main(void)
{
	setlocale(LC_ALL, "Portuguese");
	float bs,alt,area;
	printf("\ndigite o valor da base:");
	scanf("%f", &bs);
	printf("\ndigite o valor da altura:");
	scanf("%f", &alt);
	area = bs*alt/2;
	printf("\nvalor da base:%f\nvalor da altura:%f\n o valor da area e:%.3f",bs,alt,area);
}
