#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void main(void)
{
	setlocale(LC_ALL, "Portuguese");
	float R,pi,H, area;
	pi = 3.14;
	printf("\nDigite o valor do raio:");
	scanf("%f", &R);
	printf("\nDigite o valor da altura:");
	scanf("%f", &H);
	area = pi*2*R*H;
	printf("\nO valor da area do cilndro e:%.2f",area);	
}

