#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void main(void)
{
	setlocale(LC_ALL, "Portuguese");
	float R,pi,vol;
	pi = 3.14;
	printf("\nDigite o valor do raio da esfera:");
	scanf("%f", &R);
	vol = 4/3*pi*R*R*R;
	printf("\nO valor do volume da esfera e:%.2f",vol);	
}

