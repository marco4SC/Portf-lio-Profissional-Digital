#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void main(void)
{
	setlocale(LC_ALL, "Portuguese");
	float C,F;
	printf("\nDigite o valor em  graus celcius:");
	scanf("%f", &C);
	F = (C*1.8)+32;
	printf("\nO valor da temperatura em Fahrenheit:%.2f",F);	
}
