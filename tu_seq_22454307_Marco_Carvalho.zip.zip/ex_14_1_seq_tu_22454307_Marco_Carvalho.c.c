#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void main(void)
{
 setlocale(LC_ALL, "Portuguese");
 float a,b,c,med;
printf("\n Digite o valor a:" );
scanf("%f", &a);
printf("\n Digite o valor b:" );
scanf("%f", &b);
printf("\n Digite valor c:" );
scanf("%f", &c);
med = (a+b+c)/3;
printf("a media aritimetica de A B C e:%.2f",med);
}
