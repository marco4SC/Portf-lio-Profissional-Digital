#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void main(void)
{
 setlocale(LC_ALL, "Portuguese");
 float vl1,vl2,sum,sub,mult;
 printf("\ndigite o valor 1:");
 scanf("%f", &vl1),
 printf("\ndigite o valor 2:");
 scanf("%f", &vl2);
 sum = vl1+vl2;
 sub = vl1-vl2;
 mult = vl1*vl2;
 printf("A soma dos valores e:%.0f\nA subtracao dos valores e:%0.f\nA multipicacao dos valores e:%0.f",sum,sub,mult);
}
