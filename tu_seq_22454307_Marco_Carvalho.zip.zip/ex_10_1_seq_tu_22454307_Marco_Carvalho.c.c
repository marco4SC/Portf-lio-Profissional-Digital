#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void main(void)
{
	setlocale(LC_ALL, "Portuguese");
	float a,b,r;
	printf("\nDigite o valor de A:");
	scanf("%f",&a);
	printf("\nDigite o valor de B:");
	scanf("%f", &b);
	r= -b/a;
	printf("\nA raiz de ax+b=0 X(raiz) = %.2f \nonde A = %.2f \nB = %.2f ",r,a,b);
}
