#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
void main(void)
{
	setlocale(LC_ALL, "Portuguese");
	float m,p;
	printf("Digite o valor em pes:");
	scanf("%f",&p);
	m = p*0.3048;
	printf("o valor %.3f em pes e igual a %f em metros",p,m);
}
